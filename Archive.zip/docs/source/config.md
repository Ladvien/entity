```{include} ../../README.md
:relative-images:
:start-after: <!-- start config -->
:end-before: <!-- end config -->
```
