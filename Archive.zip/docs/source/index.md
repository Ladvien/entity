
```{include} ../../README.md
:relative-images:
:start-after: <!-- start quick_start -->
:end-before: <!-- end quick_start -->
```


```{toctree}
:hidden:

quick_start
config
advanced_usage
apidocs/index
```

